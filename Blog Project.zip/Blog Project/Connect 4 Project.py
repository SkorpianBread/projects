# Connect 4 Project
# Start: 01/09/2021
import pygame
import os
import random

pygame.font.init()

GRID_X = [69, 161, 253, 344, 436, 528, 619]
GRID_Y = [34, 127, 218, 309, 401, 492, 585]
NUMBERS = [0, 1, 2, 3, 4, 5]


class tile:
    def __init__(self, x, y):
        self.x = x
        self.y = y


class player_tile(tile):
    def __init__(self, x, y, x_pos, y_pos):
        super().__init__(x, y)
        self.x_pos = (
            x_pos  # In the base game, this would be the number the player types
        )
        self.y_pos = y_pos


WIDTH, HEIGHT = 780, 740
WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Connect 4")
FPS = 60
PIECE_RADIUS = 88

YELLOW_PIECE_IMAGE = pygame.image.load(os.path.join("Assets", "Yellow_piece.png"))
YELLOW_PIECE = pygame.transform.scale(YELLOW_PIECE_IMAGE, (PIECE_RADIUS, PIECE_RADIUS))

RED_PIECE_IMAGE = pygame.image.load(os.path.join("Assets", "Red_piece.png"))
RED_PIECE = pygame.transform.scale(RED_PIECE_IMAGE, (PIECE_RADIUS, PIECE_RADIUS))

BLANK_PIECE_IMAGE = pygame.image.load(os.path.join("Assets", "Blank_piece.png"))
BLANK_PIECE = pygame.transform.scale(BLANK_PIECE_IMAGE, (PIECE_RADIUS, PIECE_RADIUS))

BOARD = pygame.image.load(os.path.join("Assets", "Board.png"))
MAIN_MENU = pygame.image.load(os.path.join("Assets", "Main_Menu.png"))
RULES = pygame.image.load(os.path.join("Assets", "Rules.png"))
MENU = pygame.image.load(os.path.join("Assets", "Menu.png"))
SELECTION_MENU = pygame.image.load(os.path.join("Assets", "Selection_Menu.png"))
ARROW_IMAGE = pygame.image.load(os.path.join("Assets", "Arrow.png"))
ARROW = pygame.transform.scale(ARROW_IMAGE, (60, 40))
ARROW_UP = pygame.transform.rotate(ARROW, 90)

WINNER_FONT = pygame.font.SysFont("comicsans", 100)
POINT_FONT = pygame.font.SysFont("comicsans", 40)


def red_move(grid, full, red, red_pieces, yellow_pieces, time_limit):
    current_player = "red"
    if full[red - 1]:
        if time_limit >= 180:
            current_player = "yellow"
            yellow_pieces.append("Y")
            yellow_pieces[-1] = player_tile(GRID_X[3], GRID_Y[0], 4, 6)
            red_pieces.pop(-1)
    else:
        for i in range(len(grid)):
            if grid[-(i + 1)][red - 1] == " ":
                grid[-(i + 1)][red - 1] = "R"
                red_pieces[-1].y = GRID_Y[-(i + 1)]
                red_pieces[-1].y_pos = NUMBERS[-(i + 1)]

                current_player = "yellow"
                yellow_pieces.append("Y")
                yellow_pieces[-1] = player_tile(GRID_X[3], GRID_Y[0], 4, 6)
                break

    return current_player


def yellow_move(grid, full, yellow, red_pieces, yellow_pieces, time_limit):
    current_player = "yellow"
    if full[yellow - 1]:
        if time_limit >= 180:
            current_player = "red"
            red_pieces.append("R")
            red_pieces[-1] = player_tile(GRID_X[3], GRID_Y[0], 4, 6)
            yellow_pieces.pop(-1)
    else:
        for i in range(len(grid)):
            if grid[-(i + 1)][yellow - 1] == " ":
                grid[-(i + 1)][yellow - 1] = "Y"
                yellow_pieces[-1].y = GRID_Y[-(i + 1)]
                yellow_pieces[-1].y_pos = NUMBERS[-(i + 1)]

                current_player = "red"
                red_pieces.append("R")
                red_pieces[-1] = player_tile(GRID_X[3], GRID_Y[0], 4, 6)
                break
    return current_player


def check_if_full(grid, full):
    for x in range(len(grid[0])):
        full_count = 0
        for y in range(len(grid)):
            if grid[y][x] != " ":
                full_count += 1
        if full_count == 6:
            full[x] = True
        else:
            full[x] = False
    return full


def check_for_win(grid, win, blank_pieces, red_pieces, yellow_pieces, current_player):
    winner = ""
    red_wins, yellow_wins = False, False

    # up, down
    for x in range(len(grid[0])):
        for y in range(len(grid) - 3):
            if (
                grid[y][x] == "R"
                and grid[y + 1][x] == "R"
                and grid[y + 2][x] == "R"
                and grid[y + 3][x] == "R"
            ):
                red_wins = True
                win = True
                for i in range(0, 4):
                    for j in range(len(red_pieces)):
                        if (
                            red_pieces[j].x_pos == x + 1
                            and red_pieces[j].y_pos == y + i
                        ):
                            B = tile(red_pieces[j].x, red_pieces[j].y)
                            blank_pieces.append(B)
            if (
                grid[y][x] == "Y"
                and grid[y + 1][x] == "Y"
                and grid[y + 2][x] == "Y"
                and grid[y + 3][x] == "Y"
            ):
                yellow_wins = True
                win = True
                for i in range(0, 4):
                    for j in range(len(yellow_pieces)):
                        if (
                            yellow_pieces[j].x_pos == x + 1
                            and yellow_pieces[j].y_pos == y + i
                        ):
                            B = tile(yellow_pieces[j].x, yellow_pieces[j].y)
                            blank_pieces.append(B)

    # left, right
    for x in range(len(grid[0]) - 3):
        for y in range(len(grid)):
            if (
                grid[y][x] == "R"
                and grid[y][x + 1] == "R"
                and grid[y][x + 2] == "R"
                and grid[y][x + 3] == "R"
            ):
                red_wins = True
                win = True
                for i in range(0, 4):
                    for j in range(len(red_pieces)):
                        if (
                            red_pieces[j].x_pos == x + 1 + i
                            and red_pieces[j].y_pos == y
                        ):
                            B = tile(red_pieces[j].x, red_pieces[j].y)
                            blank_pieces.append(B)
            if (
                grid[y][x] == "Y"
                and grid[y][x + 1] == "Y"
                and grid[y][x + 2] == "Y"
                and grid[y][x + 3] == "Y"
            ):
                yellow_wins = True
                win = True
                for i in range(0, 4):
                    for j in range(len(yellow_pieces)):
                        if (
                            yellow_pieces[j].x_pos == x + 1 + i
                            and yellow_pieces[j].y_pos == y
                        ):
                            B = tile(yellow_pieces[j].x, yellow_pieces[j].y)
                            blank_pieces.append(B)

    # right, down diagonal
    for x in range(len(grid[0]) - 3):
        for y in range(len(grid) - 3):
            if (
                grid[y][x] == "R"
                and grid[y + 1][x + 1] == "R"
                and grid[y + 2][x + 2] == "R"
                and grid[y + 3][x + 3] == "R"
            ):
                red_wins = True
                win = True
                for i in range(0, 4):
                    for j in range(len(red_pieces)):
                        if (
                            red_pieces[j].x_pos == x + 1 + i
                            and red_pieces[j].y_pos == y + i
                        ):
                            B = tile(red_pieces[j].x, red_pieces[j].y)
                            blank_pieces.append(B)
            if (
                grid[y][x] == "Y"
                and grid[y + 1][x + 1] == "Y"
                and grid[y + 2][x + 2] == "Y"
                and grid[y + 3][x + 3] == "Y"
            ):
                yellow_wins = True
                win = True
                for i in range(0, 4):
                    for j in range(len(yellow_pieces)):
                        if (
                            yellow_pieces[j].x_pos == x + 1 + i
                            and yellow_pieces[j].y_pos == y + i
                        ):
                            B = tile(yellow_pieces[j].x, yellow_pieces[j].y)
                            blank_pieces.append(B)

    # left, down diagonal
    for x in range(2, len(grid[0])):
        for y in range(len(grid) - 3):
            if (
                grid[y][x] == "R"
                and grid[y + 1][x - 1] == "R"
                and grid[y + 2][x - 2] == "R"
                and grid[y + 3][x - 3] == "R"
            ):
                red_wins = True
                win = True
                for i in range(0, 4):
                    for j in range(len(red_pieces)):
                        if (
                            red_pieces[j].x_pos == (x + 1) - i
                            and red_pieces[j].y_pos == y + i
                        ):
                            B = tile(red_pieces[j].x, red_pieces[j].y)
                            blank_pieces.append(B)
            if (
                grid[y][x] == "Y"
                and grid[y + 1][x - 1] == "Y"
                and grid[y + 2][x - 2] == "Y"
                and grid[y + 3][x - 3] == "Y"
            ):
                yellow_wins = True
                win = True
                for i in range(0, 4):
                    for j in range(len(yellow_pieces)):
                        if (
                            yellow_pieces[j].x_pos == (x + 1) - i
                            and yellow_pieces[j].y_pos == y + i
                        ):
                            B = tile(yellow_pieces[j].x, yellow_pieces[j].y)
                            blank_pieces.append(B)

    if red_wins and yellow_wins:
        if current_player == "red":
            winner = "yellow"
            blank_pieces_copy = blank_pieces.copy()
            for i in range(len(blank_pieces_copy)):
                for j in range(len(red_pieces)):
                    if (
                        blank_pieces_copy[i].x == red_pieces[j].x
                        and blank_pieces_copy[i].y == red_pieces[j].y
                    ):
                        blank_pieces[i] = ""
            for k in range(4):
                blank_pieces.remove("")
        else:
            winner = "red"
            blank_pieces_copy = blank_pieces.copy()
            for i in range(len(blank_pieces_copy)):
                for j in range(len(yellow_pieces)):
                    if (
                        blank_pieces_copy[i].x == yellow_pieces[j].x
                        and blank_pieces_copy[i].y == yellow_pieces[j].y
                    ):
                        blank_pieces[i] = ""
            for k in range(4):
                blank_pieces.remove("")
    elif red_wins:
        winner = "red"
    elif yellow_wins:
        winner = "yellow"

    return win, winner, blank_pieces


def draw_window(
    red_pieces,
    yellow_pieces,
    blank_pieces,
    red_points,
    yellow_points,
    game_mode,
    time_limit,
    current_player,
):
    red_points_text = POINT_FONT.render("RED POINTS: " + str(red_points), 1, (0, 0, 0))
    yellow_points_text = POINT_FONT.render(
        "YELLOW POINTS: " + str(yellow_points), 1, (0, 0, 0)
    )

    WIN.fill((16, 189, 134))
    WIN.blit(red_points_text, (10, 10))
    WIN.blit(yellow_points_text, ((WIDTH - yellow_points_text.get_width()) - 10, 10))

    if game_mode == "speed":
        if time_limit < 60:
            count_down = "3"
        elif time_limit < 120:
            count_down = "2"
        elif time_limit < 180:
            count_down = "1"
        else:
            count_down = "0"
        count_down_text = POINT_FONT.render(count_down, 1, (0, 0, 0))
        WIN.blit(
            count_down_text, ((WIDTH // 2) - (count_down_text.get_width() // 2), 10)
        )
    elif game_mode == "pop out":
        if current_player == "red":
            WIN.blit(ARROW_UP, (red_pieces[-1].x + 26, 680))
        else:
            WIN.blit(ARROW_UP, (yellow_pieces[-1].x + 26, 680))

    for i in range(len(red_pieces)):
        WIN.blit(RED_PIECE, (red_pieces[i].x, red_pieces[i].y))

    for i in range(len(yellow_pieces)):
        WIN.blit(YELLOW_PIECE, (yellow_pieces[i].x, yellow_pieces[i].y))

    for i in range(len(blank_pieces)):
        WIN.blit(BLANK_PIECE, (blank_pieces[i].x, blank_pieces[i].y))

    WIN.blit(BOARD, (0, 100))
    pygame.display.update()


def red_pop_out(grid, red, red_pieces, yellow_pieces):
    current_player = "red"
    if grid[-1][red] == "R":
        red_pieces.pop(-1)
        grid[-1][red] = " "
        for i in range(len(grid) - 1):
            grid[-(i + 1)][red] = grid[-(i + 2)][red]

        for j in range(len(red_pieces)):
            if red_pieces[j].x_pos == red + 1:
                if red_pieces[j].y_pos == 5:
                    red_pieces.pop(j)
                    break
        for j in range(len(red_pieces)):
            if red_pieces[j].x_pos == red + 1:
                red_pieces[j].y_pos += 1
                for k in range(len(GRID_Y) - 1):
                    if red_pieces[j].y == GRID_Y[k]:
                        red_pieces[j].y = GRID_Y[k + 1]
                        break

        for j in range(len(yellow_pieces)):
            if yellow_pieces[j].x_pos == red + 1:
                yellow_pieces[j].y_pos += 1
                for k in range(len(GRID_Y) - 1):
                    if yellow_pieces[j].y == GRID_Y[k]:
                        yellow_pieces[j].y = GRID_Y[k + 1]
                        break

        current_player = "yellow"
        yellow_pieces.append("y")
        yellow_pieces[-1] = player_tile(GRID_X[3], GRID_Y[0], 4, 6)

    return current_player


def yellow_pop_out(grid, yellow, red_pieces, yellow_pieces):
    current_player = "yellow"
    if grid[-1][yellow] == "Y":
        yellow_pieces.pop(-1)
        grid[-1][yellow] = " "
        for i in range(len(grid) - 1):
            grid[-(i + 1)][yellow] = grid[-(i + 2)][yellow]

        for j in range(len(yellow_pieces)):
            if yellow_pieces[j].x_pos == yellow + 1:
                if yellow_pieces[j].y_pos == 5:
                    yellow_pieces.pop(j)
                    break
        for j in range(len(yellow_pieces)):
            if yellow_pieces[j].x_pos == yellow + 1:
                yellow_pieces[j].y_pos += 1
                for k in range(len(GRID_Y) - 1):
                    if yellow_pieces[j].y == GRID_Y[k]:
                        yellow_pieces[j].y = GRID_Y[k + 1]
                        break

        for j in range(len(red_pieces)):
            if red_pieces[j].x_pos == yellow + 1:
                red_pieces[j].y_pos += 1
                for k in range(len(GRID_Y) - 1):
                    if red_pieces[j].y == GRID_Y[k]:
                        red_pieces[j].y = GRID_Y[k + 1]
                        break

        current_player = "red"
        red_pieces.append("r")
        red_pieces[-1] = player_tile(GRID_X[3], GRID_Y[0], 4, 6)

    return current_player


def red_piece_move_handle(
    key_pressed,
    grid,
    full,
    red_pieces,
    yellow_pieces,
    time_limit,
    game_mode,
):
    current_player = "red"
    if key_pressed == pygame.K_d:
        for i in range(len(GRID_X)):
            if red_pieces[-1].x == GRID_X[i]:
                if i + 1 < 7:
                    X = i + 1
                    red_pieces[-1].x_pos += 1
                else:
                    X = i
        red_pieces[-1].x = GRID_X[X]

    elif key_pressed == pygame.K_a:
        for i in range(len(GRID_X)):
            if red_pieces[-1].x == GRID_X[i]:
                if i - 1 > -1:
                    X = i - 1
                    red_pieces[-1].x_pos -= 1
                else:
                    X = i
        red_pieces[-1].x = GRID_X[X]

    elif key_pressed == pygame.K_s:
        current_player = red_move(
            grid, full, red_pieces[-1].x_pos, red_pieces, yellow_pieces, time_limit
        )

    elif game_mode == "pop out" and key_pressed == pygame.K_w:
        current_player = red_pop_out(
            grid,
            red_pieces[-1].x_pos - 1,
            red_pieces,
            yellow_pieces,
        )

    return current_player


def yellow_piece_move_handle(
    key_pressed, grid, full, red_pieces, yellow_pieces, time_limit, game_mode
):
    current_player = "yellow"
    if key_pressed == pygame.K_RIGHT:
        for i in range(len(GRID_X)):
            if yellow_pieces[-1].x == GRID_X[i]:
                if i + 1 < 7:
                    X = i + 1
                    yellow_pieces[-1].x_pos += 1
                else:
                    X = i
        yellow_pieces[-1].x = GRID_X[X]

    elif key_pressed == pygame.K_LEFT:
        for i in range(len(GRID_X)):
            if yellow_pieces[-1].x == GRID_X[i]:
                if i - 1 > -1:
                    X = i - 1
                    yellow_pieces[-1].x_pos -= 1
                else:
                    X = i
        yellow_pieces[-1].x = GRID_X[X]

    elif key_pressed == pygame.K_DOWN:
        current_player = yellow_move(
            grid, full, yellow_pieces[-1].x_pos, red_pieces, yellow_pieces, time_limit
        )

    elif game_mode == "pop out" and key_pressed == pygame.K_UP:
        current_player = yellow_pop_out(
            grid,
            yellow_pieces[-1].x_pos - 1,
            red_pieces,
            yellow_pieces,
        )

    return current_player


def draw_win(winner):
    draw_text = WINNER_FONT.render(winner.upper() + " WINS!", 1, (255, 255, 255))
    BOX = pygame.Rect(
        (WIDTH / 2) - (draw_text.get_width() / 2),
        40,
        draw_text.get_width(),
        draw_text.get_height(),
    )
    pygame.draw.rect(WIN, (0, 0, 0), BOX)
    WIN.blit(draw_text, (WIDTH / 2 - draw_text.get_width() / 2, 40))
    pygame.display.update()
    pygame.time.delay(3666)


def game_number_selection(start, arrow_x, pos, key_pressed):
    ARROW_X = [120, 290, 460, 620]

    WIN.blit(SELECTION_MENU, (0, 0))
    if key_pressed == pygame.K_RIGHT:
        pos += 1
        if pos == 4:
            pos = 0
        arrow_x = ARROW_X[pos]
    elif key_pressed == pygame.K_LEFT:
        pos -= 1
        if pos == -4:
            pos = 0
        arrow_x = ARROW_X[pos]
    elif key_pressed == pygame.K_RETURN:
        start = True

    WIN.blit(ARROW_UP, (arrow_x, 400))
    pygame.display.update()

    return start, arrow_x, pos


def menu(selected, arrow_y, pos, key_pressed, play):
    ARROW_Y = [246, 340, 430, 540]

    WIN.blit(MENU, (0, 0))

    if key_pressed == pygame.K_DOWN:
        pos += 1
        if pos == 4:
            pos = 0
        arrow_y = ARROW_Y[pos]
    elif key_pressed == pygame.K_UP:
        pos -= 1
        if pos == -4:
            pos = 0
        arrow_y = ARROW_Y[pos]
    elif key_pressed == pygame.K_RETURN:
        selected = True
        if pos == 3:
            play = False
            selected = False

    WIN.blit(ARROW, (210, arrow_y))
    pygame.display.update()

    return selected, arrow_y, pos, play


def main_menu_handle(play, arrow_y, pos, key_pressed, quit, run, rules):
    ARROW_Y = [346, 436, 580]

    WIN.blit(MAIN_MENU, (0, 0))

    if key_pressed == pygame.K_DOWN:
        pos += 1
        if pos == 3:
            pos = 0
        arrow_y = ARROW_Y[pos]
    elif key_pressed == pygame.K_UP:
        pos -= 1
        if pos == -1:
            pos = 2
        arrow_y = ARROW_Y[pos]
    elif key_pressed == pygame.K_RETURN:
        if pos == 0:
            play = True
        elif pos == 1:
            rules = True
        elif pos == 2:
            quit = True
            play = False
            run = False

    WIN.blit(ARROW, (230, arrow_y))
    pygame.display.update()

    return play, arrow_y, pos, quit, run, rules


def menu_handle(clock):
    run = True
    play = False
    start = False
    selected = False
    rules = False
    quit = False

    arrow_y, pos = 246, 0
    arrow_x, pos_gn = 120, 0  # gn = game number
    arrow_y_mm, pos_mm = 346, 0  # mm = main menu
    key_pressed = ""
    GAME_NUMBERS = [1, 3, 5, 7]
    GAME_MODES = ["classic", "speed", "pop out", "quit"]

    while run:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quit = True
                run = False
            if event.type == pygame.KEYDOWN:
                key_pressed = event.key

        if not play:
            if not rules:
                play, arrow_y_mm, pos_mm, quit, run, rules = main_menu_handle(
                    play, arrow_y_mm, pos_mm, key_pressed, quit, run, rules
                )
                key_pressed = ""
            else:
                WIN.blit(RULES, (0, 0))
                pygame.display.update()
                if key_pressed == pygame.K_RETURN:
                    rules = False
                    key_pressed = ""

        elif not selected:
            selected, arrow_y, pos, play = menu(
                selected, arrow_y, pos, key_pressed, play
            )
            key_pressed = ""

        elif selected:
            start, arrow_x, pos_gn = game_number_selection(
                start, arrow_x, pos_gn, key_pressed
            )
            key_pressed = ""
            if start:
                run = False

    return GAME_MODES[pos], GAME_NUMBERS[pos_gn], quit


def pygame_main():
    clock = pygame.time.Clock()

    red_points, yellow_points = 0, 0
    random_number = random.randint(1, 2)
    if random_number == 1:
        winner = "red"
    else:
        winner = "yellow"

    game_mode, number_of_games, quit = menu_handle(clock)

    for i in range(number_of_games):
        grid = [[" " for i in range(7)] for i in range(6)]
        full = ["" for i in range(7)]
        win = False
        run = False

        red_pieces = []
        yellow_pieces = []
        blank_pieces = []

        current_player = winner.lower()
        if current_player == "red":
            red_pieces.append("R")
            red_pieces[0] = player_tile(GRID_X[3], GRID_Y[0], 4, 6)
        else:
            yellow_pieces.append("Y")
            yellow_pieces[0] = player_tile(GRID_X[3], GRID_Y[0], 4, 6)

        time_limit = 0

        if not quit:
            run = True

        while run:
            clock.tick(FPS)

            if game_mode == "speed":
                time_limit += 1

            if time_limit >= 180:
                if current_player == "red":
                    current_player = red_move(
                        grid,
                        full,
                        red_pieces[-1].x_pos,
                        red_pieces,
                        yellow_pieces,
                        time_limit,
                    )
                    time_limit = 0
                else:
                    current_player = yellow_move(
                        grid,
                        full,
                        yellow_pieces[-1].x_pos,
                        red_pieces,
                        yellow_pieces,
                        time_limit,
                    )
                    time_limit = 0

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    run = False
                    quit = True

                if event.type == pygame.KEYDOWN:
                    if current_player == "red":
                        if (
                            event.key == pygame.K_s
                            and not full[red_pieces[-1].x_pos - 1]
                        ):
                            time_limit = 0

                        current_player = red_piece_move_handle(
                            event.key,
                            grid,
                            full,
                            red_pieces,
                            yellow_pieces,
                            time_limit,
                            game_mode,
                        )

                    elif current_player == "yellow":
                        if (
                            event.key == pygame.K_DOWN
                            and not full[yellow_pieces[-1].x_pos - 1]
                        ):
                            time_limit = 0

                        current_player = yellow_piece_move_handle(
                            event.key,
                            grid,
                            full,
                            red_pieces,
                            yellow_pieces,
                            time_limit,
                            game_mode,
                        )

            full = check_if_full(grid, full)
            win, winner, blank_pieces = check_for_win(
                grid,
                win,
                blank_pieces,
                red_pieces,
                yellow_pieces,
                current_player,
            )
            draw_window(
                red_pieces,
                yellow_pieces,
                blank_pieces,
                red_points,
                yellow_points,
                game_mode,
                time_limit,
                current_player,
            )

            if win:
                if winner == "red":
                    red_points += 1
                else:
                    yellow_points += 1

                draw_window(
                    red_pieces,
                    yellow_pieces,
                    blank_pieces,
                    red_points,
                    yellow_points,
                    game_mode,
                    time_limit,
                    current_player,
                )
                draw_win(winner)
                run = False

    if not quit:
        pygame_main()
    pygame.quit()


if __name__ == "__main__":
    pygame_main()
